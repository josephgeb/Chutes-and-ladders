#include "board.h"
#include "player.h"
#include <iostream>

int main() {
    Board board;

    Player player1("Player 1");
    Player player2("Player 2");

    int currentPlayer = 0;
    while (!board.isWinner(currentPlayer)) {
        board.turn(currentPlayer);

        std::cout << "Board state after Player " << currentPlayer + 1 << "'s turn:" << std::endl;
        board.printBoard();
        std::cout << std::endl;

        if (currentPlayer == 0) {
            player1.printStats();
        } else {
            player2.printStats();
        }

        currentPlayer = (currentPlayer + 1) % 2;
    }

    std::cout << "Player " << currentPlayer + 1 << " wins!" << std::endl;

    return 0;
}
