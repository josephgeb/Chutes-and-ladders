#ifndef BOARD_H
#define BOARD_H

#include <cstdlib> 
#include <ctime> 

class Board {
public:
    Board();
    int turn(int player);
    void printBoard() const;
    bool isWinner(int player) const;

private:
    static const int size = 100; 
    int players[6];  
    int chutesLadders[size + 1];


    int spin() const;
};

#endif
