// player.cpp
#include "player.h"
#include <iostream>

Player::Player(): chutesReached(0), laddersReached(0) {

}

Player::Player(const std::string& name) : playerName(name),  chutesReached(0), laddersReached(0) {
}

std::string Player::getName() const {
    return playerName;
}

int Player::getChutesReached() {
    return chutesReached;
}

void Player::incrementChutesReached() {
    chutesReached++;
}

int Player::getLaddersReached() {
    return laddersReached;
}

void Player::incrementLaddersReached() {
    laddersReached++;
}

void Player::printStats() const {
    std::cout << "Player: " << playerName << "\n"
              << "Chutes Reached: " << chutesReached << "\n"
              << "Ladders Reached: " << laddersReached << std::endl;
}
