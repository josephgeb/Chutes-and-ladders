#include "board.h"
#include <iostream>
#include <ctime> // Include ctime for time function
using namespace std;

Board::Board() {
  // Initialization code
  for (int i = 0; i < 6; ++i) {
    players[i] = 0;
  }

  // Set up chutes and ladders
  chutesLadders[1] = 37;
  chutesLadders[4] = 10;
  chutesLadders[9] = 12;
  chutesLadders[23] = 21;
  chutesLadders[28] = 56;
  chutesLadders[36] = 8;
  chutesLadders[51] = 15;
  chutesLadders[71] = 19;
  chutesLadders[80] = 20;

  chutesLadders[98] = -20;
  chutesLadders[95] = -20;
  chutesLadders[93] = -20;
  chutesLadders[87] = -63;
  chutesLadders[64] = -4;
  chutesLadders[62] = -43;
  chutesLadders[56] = -3;
  chutesLadders[49] = -38;
  chutesLadders[48] = -22;
  chutesLadders[16] = -10;

  // random number generation
  srand(static_cast<unsigned>(time(0)));
}

int Board::turn(int player) {
  // Perform a turn for the specified player
  int spinResult = spin();
  players[player] += spinResult;

  // Check for chutes or ladders
  if (players[player] <= size && chutesLadders[players[player]] != 0) {
    players[player] += chutesLadders[players[player]];
  }

  if (players[player] > 95) {
    if (spinResult != 1) {
      players[player] -= spinResult;
    }
  }

  return players[player];
}

void Board::printBoard() const {
  // Add code to print the current board state
  for (int i = 0; i < 6; ++i) {
    cout << "Player " << i+1 << " Position: " << players[i] << endl;
  }
}

bool Board::isWinner(int player) const {
  // Check if the player has won
  return players[player] >= 100;
}

int Board::spin() const { return (rand() % 6) + 1; }
