#ifndef PLAYER_H
#define PLAYER_H

#include <string>
using namespace std;

class Player {
public:
    Player();
    Player(const string& name);  
    string getName() const; 
    void printStats() const;
    int getChutesReached() ;  
    void incrementChutesReached();  
    int getLaddersReached();  
    void incrementLaddersReached();  
private:
    string playerName;
    int chutesReached;
    int laddersReached;
};

#endif
